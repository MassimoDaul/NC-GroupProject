# NYU CS 421 Numerical Computing SPH Project
# Prepared by Dr. Gizem Kayar in April 2026
# Completed by:
#   - Massimo Dual
#   - Caleb Ashes

###############################################################################
# SPH CORNER DAM-BREAK SIMULATION
#
# This file implements the simulation part of the project.
# It writes particle positions to CSV files in the output/ folder.
# A separate visualizer can read those CSV files and animate the motion.
#
# Covered here:
#   TODO 1: Initialize CBD particles
#   TODO 2: Grid-based neighbor search / spatial hashing
#   TODO 3: Density computation
#   TODO 4: Pressure and viscosity forces
#   TODO 5: Euler-Cromer integration
#
# Later experiments:
#   TODO 6: Change parameters and note behavior
#   TODO 7: Try other kernels
#   TODO 8: Enlarge initial particle block
#   TODO 9: Compare spatial hashing with naive O(n^2) neighbor search
#   TODO 10: Compare Euler-Cromer with explicit Euler
###############################################################################

using LinearAlgebra
using CSV
using DataFrames
using FileIO

# -----------------------------
# Parameters
# -----------------------------

# TODO 6: These are the parameters you can later vary experimentally.
const h = 0.04
const mass = 1.06
const rho0 = 1000.0
const k = 3000.0
const mu = 0.1
const g = [0.0, -9.8]
const dt = 2.0e-5

# For testing, you may want to start smaller, e.g. STEPS = 5000.
const STEPS = 5000
const SAVE_EVERY = 10
const dx = h * 0.8

# Domain is the unit square [0,1] x [0,1].
const cell_size = h
const grid_res = Int(ceil(1.0 / cell_size))

# Boundary damping constants.
# These make wall collisions lose energy instead of bouncing perfectly.
const wall_damping_x = -0.5
const wall_damping_y = -0.3

# -----------------------------
# Kernels
# -----------------------------

# TODO 7: Later, you can replace these with other kernels, e.g. cubic spline.

# Poly6 kernel for density estimation.
W_poly6(r) = (0 ≤ r ≤ h) ? 4 / (pi * h^8) * (h^2 - r^2)^3 : 0.0

# Spiky kernel gradient for pressure forces.
function gradW_spiky(rvec)
    r = norm(rvec)
    return (0 < r ≤ h) ? -30 / (pi * h^5) * (h - r)^2 * (rvec / r) : zeros(2)
end

# Viscosity kernel Laplacian.
lapW_visc(r) = (0 ≤ r ≤ h) ? 20 / (3 * pi * h^5) * (h - r) : 0.0

# -----------------------------
# Initialization: corner dam
# -----------------------------

function init_particles()
    pos = Vector{Vector{Float64}}()
    vel = Vector{Vector{Float64}}()

    # TODO 1:
    # Dense block in lower-left corner.
    # The assignment suggests:
    #   x from dx to 0.4
    #   y from dx to 0.6
    # with spacing dx.
    #
    # TODO 8:
    # Later, enlarge this block and record the new particle count/performance.
    for x in dx:dx:0.4
        for y in dx:dx:0.6
            push!(pos, [x, y])
            push!(vel, [0.0, 0.0])
        end
    end

    Np = length(pos)
    rho = zeros(Np)
    P = zeros(Np)

    println("Initialized $Np particles.")

    return pos, vel, rho, P
end

# -----------------------------
# Grid: spatial hashing
# -----------------------------

function build_grid(pos)
    grid = Dict{Tuple{Int,Int},Vector{Int}}()

    for i in eachindex(pos)
        cx = clamp(Int(floor(pos[i][1] / cell_size)), 0, grid_res)
        cy = clamp(Int(floor(pos[i][2] / cell_size)), 0, grid_res)
        key = (cx, cy)

        if haskey(grid, key)
            push!(grid[key], i)
        else
            grid[key] = [i]
        end
    end

    return grid
end

# -----------------------------
# Neighbor search
# -----------------------------

function find_neighbors(pos, grid)
    neighbors = [Int[] for _ in eachindex(pos)]

    # TODO 2:
    # For each particle:
    #   1. Find its grid cell.
    #   2. Check the surrounding 3x3 block of cells.
    #   3. Add particle j if it is within radius h.
    #
    # TODO 9:
    # Later, replace this with the naive O(n^2) version and compare runtime.
    for i in eachindex(pos)
        cx = clamp(Int(floor(pos[i][1] / cell_size)), 0, grid_res)
        cy = clamp(Int(floor(pos[i][2] / cell_size)), 0, grid_res)

        for ox in -1:1
            for oy in -1:1
                key = (cx + ox, cy + oy)

                if haskey(grid, key)
                    for j in grid[key]
                        if i != j
                            r = norm(pos[i] - pos[j])
                            if r ≤ h
                                push!(neighbors[i], j)
                            end
                        end
                    end
                end
            end
        end
    end

    return neighbors
end

# Naive neighbor search for TODO 9.
# Do not use this in the main run unless you are doing the comparison.
function find_neighbors_naive(pos)
    neighbors = [Int[] for _ in eachindex(pos)]

    for i in eachindex(pos)
        for j in eachindex(pos)
            if i != j
                r = norm(pos[i] - pos[j])
                if r ≤ h
                    push!(neighbors[i], j)
                end
            end
        end
    end

    return neighbors
end

# -----------------------------
# Density and pressure
# -----------------------------

function compute_density!(pos, rho, neighbors)
    for i in eachindex(pos)
        # Self contribution.
        ρ = mass * W_poly6(0.0)

        # TODO 3:
        # Sum contributions from neighboring particles.
        for j in neighbors[i]
            r = norm(pos[i] - pos[j])
            ρ += mass * W_poly6(r)
        end

        # Prevent division-by-zero or tiny-density problems later.
        rho[i] = max(ρ, 1e-6)
    end
end

# Weakly compressible SPH pressure law.
compute_pressure!(rho, P) = (P .= max.(k .* (rho .- rho0), 0.0))

# -----------------------------
# Forces
# -----------------------------

function compute_forces(pos, vel, rho, P, neighbors)
    forces = [zeros(2) for _ in eachindex(pos)]

    for i in eachindex(pos)
        f_p = zeros(2)
        f_v = zeros(2)

        for j in neighbors[i]
            rij = pos[i] - pos[j]
            r = norm(rij)

            if r > 0 && r ≤ h
                # TODO 4:
                # Symmetric pressure force.
                # The symmetric form averages pressure over both particles and
                # is usually more stable than using only P[i].
                f_p += -mass * (P[i] / rho[i]^2 + P[j] / rho[j]^2) * gradW_spiky(rij)

                # Viscosity force.
                f_v += mu * mass * (vel[j] - vel[i]) / rho[j] * lapW_visc(r)
            end
        end

        # Gravity is acceleration-like here, so we add it directly.
        forces[i] = f_p + f_v + g
    end

    return forces
end

# -----------------------------
# Integration: Euler-Cromer
# -----------------------------

function integrate!(pos, vel, accel)
    # TODO 5:
    # Euler-Cromer / semi-implicit Euler:
    #   v_{n+1} = v_n + dt*a_n
    #   x_{n+1} = x_n + dt*v_{n+1}
    #
    # TODO 10:
    # Later, compare this with explicit Euler, which would update position
    # using the old velocity instead.

    for i in eachindex(pos)
        vel[i] += dt * accel[i]
        pos[i] += dt * vel[i]

        # Boundary handling.
        # Left wall.
        if pos[i][1] < 0.0
            pos[i][1] = 0.0
            vel[i][1] *= wall_damping_x
        end

        # Right wall.
        if pos[i][1] > 1.0
            pos[i][1] = 1.0
            vel[i][1] *= wall_damping_x
        end

        # Bottom wall.
        if pos[i][2] < 0.0
            pos[i][2] = 0.0
            vel[i][2] *= wall_damping_y
        end

        # Top is open in the assignment description.
        # We still prevent particles from flying too far away numerically.
        # This is not a reflective top wall.
        if pos[i][2] > 1.5
            pos[i][2] = 1.5
            vel[i][2] = 0.0
        end
    end
end

# Explicit Euler version for TODO 10.
# Do not use this in the main run unless you are doing the comparison.
function integrate_explicit_euler!(pos, vel, accel)
    for i in eachindex(pos)
        pos[i] += dt * vel[i]
        vel[i] += dt * accel[i]

        if pos[i][1] < 0.0
            pos[i][1] = 0.0
            vel[i][1] *= wall_damping_x
        end

        if pos[i][1] > 1.0
            pos[i][1] = 1.0
            vel[i][1] *= wall_damping_x
        end

        if pos[i][2] < 0.0
            pos[i][2] = 0.0
            vel[i][2] *= wall_damping_y
        end

        if pos[i][2] > 1.5
            pos[i][2] = 1.5
            vel[i][2] = 0.0
        end
    end
end

# -----------------------------
# Optional XSPH smoothing
# -----------------------------

function xsph!(vel, pos, rho, neighbors)
    ε = 0.5
    newvel = deepcopy(vel)

    for i in eachindex(pos)
        corr = zeros(2)

        for j in neighbors[i]
            corr += mass * (vel[j] - vel[i]) / rho[j] * W_poly6(norm(pos[i] - pos[j]))
        end

        newvel[i] += ε * corr
    end

    for i in eachindex(vel)
        vel[i] = newvel[i]
    end
end

# -----------------------------
# CSV output
# -----------------------------

function save_csv(pos, step)
    outdir = "output"
    isdir(outdir) || mkdir(outdir)

    filename = joinpath(outdir, "sph_$(lpad(step, 6, '0')).csv")

    open(filename, "w") do io
        for p in pos
            println(io, "$(p[1]),$(p[2])")
        end
    end
end

# -----------------------------
# Main loop
# -----------------------------

function run()
    pos, vel, rho, P = init_particles()

    # Save initial frame.
    save_csv(pos, 0)

    for step in 1:STEPS
        grid = build_grid(pos)
        neighbors = find_neighbors(pos, grid)

        compute_density!(pos, rho, neighbors)
        compute_pressure!(rho, P)

        accel = compute_forces(pos, vel, rho, P, neighbors)

        # Optional: uncomment this if the particles look too noisy.
        # xsph!(vel, pos, rho, neighbors)

        integrate!(pos, vel, accel)

        if step % SAVE_EVERY == 0
            save_csv(pos, step)
        end

        if step % 1000 == 0
            println("Completed step $step / $STEPS")
        end
    end

    println("Done. CSV frames saved in output/.")
end

run()

const output_dir = "output"
const pause_time = 0.001

# -----------------------------
# Helper: extract frame number
# -----------------------------

function frame_number(file)
    m = match(r"sph_(\d+)\.csv$", basename(file))

    if m === nothing
        error("Bad filename format: $file")
    end

    return parse(Int, m.captures[1])
end

# -----------------------------
# Load frame files
# -----------------------------

files = sort(
    filter(f -> endswith(f, ".csv"), readdir(output_dir; join=true));
    by=frame_number
)

isempty(files) && error("No CSV files found in $output_dir. Run the simulation first.")

println("Found $(length(files)) frames.")
println("First frame: $(files[1])")
println("Last frame:  $(files[end])")

# -----------------------------
# Read first frame
# -----------------------------

df = CSV.read(files[1], DataFrame; header=false)
rename!(df, [:x, :y])

xs = Observable(df.x)
ys = Observable(df.y)

# -----------------------------
# Create figure
# -----------------------------

fig = Figure(size=(700, 700))
ax = Axis(
    fig[1, 1],
    limits=(0, 1, 0, 1),
    xlabel="x",
    ylabel="y",
    title="SPH Corner Dam-Break Simulation"
)

scatter!(ax, xs, ys; markersize=14, color=:blue, alpha=0.65)

# display(fig)

# -----------------------------
# Animation loop
# -----------------------------

println("Animating. Close the Makie window or interrupt Julia to stop.")

# while true
#     for file in files
#         df = CSV.read(file, DataFrame; header=false)
#         rename!(df, [:x, :y])

#         if nrow(df) == 0
#             continue
#         end

#         xs[] = df.x
#         ys[] = df.y

#         sleep(pause_time)
#         yield()
#     end
# end

record(fig, "simulation.mp4", 1:length(files); framerate=30) do frame_idx
    file = files[frame_idx]
    df = CSV.read(file, DataFrame; header=false)
    rename!(df, [:x, :y])

    if nrow(df) > 0
        xs[] = df.x
        ys[] = df.y
    end
end

println("Saved simulation to simulation.mp4")